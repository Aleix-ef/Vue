<script>
export default {
    data() {
        return {
            title: "Cosas a hacer este año",
        };
    },
};
</script>

<template>
    <h1>{{ title }}</h1>
</template>